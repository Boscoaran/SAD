.. currentmodule:: imblearn

===============
Release history
===============

.. include:: whats_new/v0.0.4.rst

.. include:: whats_new/v0.0.3.rst

.. include:: whats_new/v0.0.2.rst

.. include:: whats_new/v0.0.1.rst
