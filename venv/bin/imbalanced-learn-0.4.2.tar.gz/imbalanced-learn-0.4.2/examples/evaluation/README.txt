.. _evaluation_examples:

Evaluation examples
-------------------

Examples illustrating how classification using imbalanced dataset can be done.
